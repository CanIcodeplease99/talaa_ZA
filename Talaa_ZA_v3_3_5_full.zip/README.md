# Talaa South Africa v3_3_5_full
Includes store metadata, privacy policies, CI/CD, and secrets scaffold.
