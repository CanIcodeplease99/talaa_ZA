# Secrets — South Africa
Set Android/iOS/Backend creds in GitHub Actions.
